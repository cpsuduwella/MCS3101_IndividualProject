import os

os.system('nmcli d wifi connect cps password 12345678 iface wlp2s0')

