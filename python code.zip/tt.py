import random

x = random.random()
u = "\"VLC001\" Cleartext-Password := \"" + str(x) + "\""
print u
